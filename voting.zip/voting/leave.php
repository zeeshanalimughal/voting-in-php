<?php
    include "config.php";
    unset($_SESSION['duration']);
    header("Location: index.php");
?>